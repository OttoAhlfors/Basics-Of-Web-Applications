import "./styles.css";

if (document.readyState !== "loading") {
  initializeCode();
} else {
  document.addEventListener("DOMContentLoaded", function () {
    initializeCode();
  });
}

function initializeCode() {
  const helloWorldButton = document.getElementById("my-button");
  const addListItemButton = document.getElementById("add-data");

  helloWorldButton.addEventListener("click", function () {
    console.log("hello world");
    document.getElementById("headline").innerHTML = "My notebook";
  });

  addListItemButton.addEventListener("click", function () {
    const listItem = document.getElementById("list");
    let li = document.createElement("li");
    li.appendChild(
      document.createTextNode(document.getElementById("list-input").value)
    );
    listItem.appendChild(li);
  });
}
