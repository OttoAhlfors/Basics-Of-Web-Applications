import "./styles.css";

if (document.readyState !== "loading") {
  initializeCode();
} else {
  document.addEventListener("DOMContentLoaded", function () {
    initializeCode();
  });
}

async function initializeCode() {
  const table = document.getElementById("data-table");

  //Population data
  const urlmun =
    "https://statfin.stat.fi/PxWeb/sq/4e244893-7761-4c4f-8e55-7a8d41d86eff ";
  const data = await fetch(urlmun);
  const dataJSON = await data.json();

  //Employment data
  const urlemp =
    "https://statfin.stat.fi/PxWeb/sq/5e288b40-f8c8-4f1e-b3b0-61b86ce5c065";
  const empdata = await fetch(urlemp);
  const empJSON = await empdata.json();

  //For each data row in url
  Object.values(dataJSON.dataset.dimension.Alue.category.label).forEach(
    (muni, index) => {
      let tr = document.createElement("tr");
      let municipality = document.createElement("td");
      let population = document.createElement("td");
      let employment = document.createElement("td");
      let employmentPersentage = document.createElement("td");
      let lasku = 0;

      //Take data from data structure
      municipality.innerText = muni;
      population.innerText = dataJSON.dataset.value[index];
      employment.innerText = empJSON.dataset.value[index];
      lasku =
        (empJSON.dataset.value[index] / dataJSON.dataset.value[index]) * 100;
      employmentPersentage.innerText = lasku.toFixed(2);

      //Insert to table
      tr.appendChild(municipality);
      tr.appendChild(population);
      tr.appendChild(employment);
      tr.appendChild(employmentPersentage);
      table.appendChild(tr);

      //Change background color based on %
      if (lasku < 25) {
        tr.style.backgroundColor = "#ff9e9e";
      }
      if (lasku > 45) {
        tr.style.backgroundColor = "#abffbd";
      }
    }
  );
}
