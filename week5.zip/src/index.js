import "./styles.css";
import L, { Layer } from "leaflet";

const fetchData = async () => {
  const munUrl =
    "https://geo.stat.fi/geoserver/wfs?service=WFS&version=2.0.0&request=GetFeature&typeName=tilastointialueet:kunta4500k&outputFormat=json&srsName=EPSG:4326";
  const munRes = await fetch(munUrl);
  const munData = await munRes.json();

  console.log(munData);

  const negUrl =
    "https://statfin.stat.fi/PxWeb/sq/944493ca-ea4d-4fd9-a75c-4975192f7b6e";
  const negRes = await fetch(negUrl);
  const negData = await negRes.json();

  console.log(negData);

  const posUrl =
    "https://statfin.stat.fi/PxWeb/sq/4bb2c735-1dc3-4c5e-bde7-2165df85e65f";
  const posRes = await fetch(posUrl);
  const posData = await posRes.json();

  initMap(munData, negData, posData);
};

const initMap = (munData, negData, posData) => {
  Object.values(negData.dataset.value).forEach((element) => {
    //console.log(element);
  });

  Object.values(posData.dataset.value).forEach((element) => {
    //console.log(element);
  });

  let map = L.map("map", {
    minZoom: -3
  });

  let geoJson = L.geoJSON(munData, {
    onEachFeature: GetFeature
  }).addTo(map);

  let osm = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "© OpenStreetMap"
  }).addTo(map);

  /*let openstreetmap = L.tileLayer(
    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    { maxZoom: 20, minZoom: 0 }
  ).addTo(map);*/

  map.fitBounds(geoJson.getBounds());
};

const GetFeature = (feature, layer) => {
  if (!feature.properties.name) return;
  const name = feature.properties.name;
  if (feature.id != null) {
    const id = feature.id;
    const splitId = id.split(".");
    console.log(splitId[1]);
  }
  layer.bindTooltip(name);
};

fetchData();
