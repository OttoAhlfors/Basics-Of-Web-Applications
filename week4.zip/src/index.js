import "./styles.css";

if (document.readyState !== "loading") {
  initializeCode();
} else {
  document.addEventListener("DOMContentLoaded", function () {
    initializeCode();
  });
}

function initializeCode() {
  const submitForm = document.getElementById("submit-data");

  submitForm.addEventListener("click", async function () {
    var name = document.getElementById("input-show").value;

    var url = "https://api.tvmaze.com/search/shows?q=" + name;
    const data = await fetch(url);
    const dataJSON = await data.json();

    Object.values(dataJSON).forEach((object) => {
      var showName = object.show.name;
      var showSummary = object.show.summary;
      if (object.show.image !== null)
        var showImageMedium = object.show.image.medium;

      var show = document.createElement("div");
      var image = document.createElement("img");
      var info = document.createElement("div");
      var title = document.createElement("h1");
      var summary = document.createElement("p");

      show.classList.add("show-data");
      image.src = showImageMedium;
      info.classList.add("show-info");

      title.innerText = showName;
      summary.innerHTML = showSummary;

      document.body.appendChild(show);
      show.appendChild(image);
      show.appendChild(info);
      info.appendChild(title);
      info.appendChild(summary);
    });
  });
}
