import "./styles.css";

if (document.readyState !== "loading") {
  initializeCode();
} else {
  document.addEventListener("DOMContentLoaded", function () {
    initializeCode();
  });
}

function initializeCode() {
  const submitForm = document.getElementById("submit-data");
  const clearTable = document.getElementById("empty-table");
  var table = document.getElementById("data");

  //https://www.w3schools.com/jsref/met_table_insertrow.asp
  submitForm.addEventListener("click", function () {
    var username = document.getElementById("input-username").value;
    var moduser = document.getElementById(username);
    var email = document.getElementById("input-email").value;
    var address = document.getElementById("input-address").value;
    var admin = document.getElementById("input-admin").checked;
    var file = document.getElementById("input-image").files[0] ?? false;
    const image = document.createElement("img");

    if (moduser == null) {
      var newRow = table.insertRow();
      newRow.id = username;

      var newCell1 = newRow.insertCell(0);
      var newCell2 = newRow.insertCell(1);
      var newCell3 = newRow.insertCell(2);
      var newCell4 = newRow.insertCell(3);
      var newCell5 = newRow.insertCell(4);

      //https://developer.mozilla.org/en-US/docs/Web/API/File_API/Using_files_from_web_applications#example_using_object_urls_to_display_images
      if (file !== false) {
        image.src = URL.createObjectURL(file);
        image.height = 64;
        image.width = 64;
        newCell5.appendChild(image);
      }

      newCell1.innerHTML = username;
      newCell2.innerHTML = email;
      newCell3.innerHTML = address;
      newCell4.innerHTML = admin ? "X" : "-";
    } else {
      var modRow = document.getElementById(username);
      modRow.cells[1].innerHTML = email;
      modRow.cells[2].innerHTML = address;
      modRow.cells[3].innerHTML = admin;

      if (file !== false) {
        image.src = URL.createObjectURL(file);
        image.height = 64;
        image.width = 64;
        modRow.cells[4].replaceChild(image, image);
      }
    }
  });

  clearTable.addEventListener("click", function () {
    while (table.hasChildNodes()) {
      table.removeChild(table.lastChild);
    }
  });
}
